 import java.io.Serializable;
 
 class GetLocalTime implements Serializable {
	static int tyme;
	static int valid;
}