 import java.io.Serializable;
 
 class GetLocalOS implements Serializable {
	static int version;
}