Hi,

I have developed the java code using Eclipse IDE and executed it in the same. I set the prefrences for all in the IDE.
For windows I have to start rmiregistry in source folder where all java files are located. 

The program for JNI is coded in Visual C compiler which has minor differences from gcc on linux.
The library file for the JNI for Java is located in the following path AgentC\bin\Debug of the zip folder.

The functionality is working on my system, please let me know if it is working on your system.
Since we have transitioned to online classes, it will be difficult to meet and demonstrate. 
Kindly let me know how to proceed.